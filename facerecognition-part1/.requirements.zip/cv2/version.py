opencv_version = "3.4.10.37"
contrib = False
headless = True
ci_build = True